package com.coforge.ems.service;

import java.sql.SQLException;

import com.coforge.ems.dao.EmployeeDAO;
import com.coforge.ems.exception.InvalidEmployeeObjectException;
import com.coforge.ems.model.Employee;

public class EmployeeService {
	
	private EmployeeDAO dao = new EmployeeDAO();
	
	public int createEmployee(Employee emp) throws ClassNotFoundException,SQLException,InvalidEmployeeObjectException{
		int n = 0;
		if(employee !=null && employee.getEmpId() > 0 && employee.getEmpName() != null && employee.getEmpSal() > 0)
			n = dao.createEmployee(employee);
		else
			throw new InvalidEmployeeObjectException();
	}
	return n;

}
