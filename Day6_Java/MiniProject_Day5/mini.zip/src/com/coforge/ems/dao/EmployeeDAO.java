package com.coforge.ems.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.coforge.ems.model.Employee;
import com.coforge.ems.util.DBUtil;

public class EmployeeDAO {
	
	public int createEmployee(Employee emp) {
		int n = 0;
		Connection connection = DBUtil.getDBCConnection();
		
		String sql = "insert into tbl_employee values (? , ? , ? , ?)";
		PreparedStatement statement = connection.prepareStatement(sql);
		
		statement.setInt(1 ,  emp.getEmpId());
		statement.setInt(1 ,  emp.getEmpName());
		statement.setInt(1 ,  emp.getEmpSal());
		statement.setInt(1 ,  emp.getEmpDno());
		
		
		
		return n;
	}

}
