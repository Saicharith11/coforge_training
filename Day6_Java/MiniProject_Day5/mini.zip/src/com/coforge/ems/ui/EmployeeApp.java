package com.coforge.ems.ui;

import java.util.Scanner;

import com.coforge.ems.controller.EmployeeController;
import com.coforge.ems.model.Employee;

public class EmployeeApp {
	private static EmployeeController controller = new EmployeeController();
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String confirmation = "" , result = "";
		do {
		System.out.println("1.Create 2.Update 3.Delete 4.Find 5.Find All 6.Exit");
		System.out.println("Enter Your Choice");
		int choice = sc.nextInt();
			switch(choice) {
			case 1:
				System.out.println("Enter Employee id , name , salary and dno");
				Employee emp = new Employee(sc.nextInt() , sc.next() ,sc.nextInt(), sc.nextInt());
				result = controller.createEmployee(emp);
				System.out.println(result);
				break;
			case 2:
				System.out.println("Enter the required row to update data");
				break;
			case 3:
				System.out.println("Enter the Row required to Delete");
				break;
			case 4:
				System.out.println("Division : ");
				break;
			case 5: 
				controller.findALLEmployee();
				System.exit(0);
			case 6:
				System.exit(0);
			default:
				System.out.println("Invalid Choice");
				break;
				
			}		
			System.out.println("Do you want to continue [Yes | No]");
			confirmation = sc.next();
		}while(confirmation.equalsIgnoreCase("Yes"));
		
		sc.close();
		
	}
}
