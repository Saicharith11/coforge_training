package com.coforge.ems.exception;

public class InvalidEmployeeObjectException {

}
