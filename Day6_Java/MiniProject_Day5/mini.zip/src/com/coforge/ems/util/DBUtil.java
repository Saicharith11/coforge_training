package com.coforge.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	public static void main(String[] args) throws ClassNotFoundException , SQLException {
		//Step - 1 Loading DARIVER // employeemanagement
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeemanagement" ,
				"root" , "Mailonly123_");
	}
}
