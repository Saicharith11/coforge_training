package com.coforge.ems.util;

public class ApplicationProperties {
	//DataBase Constants 
	
	public static final driver = "com.mysql.cj.jdbc.Driver";

}
