package com.coforge.ems.controller;

import java.sql.SQLException;

import com.coforge.ems.exception.InvalidEmployeeObjectException;
import com.coforge.ems.model.Employee;
import com.coforge.ems.service.EmployeeService;

public class EmployeeController {
	private EmployeeService service = new EmployeeService();
	
	public String createEmployee(Employee employee) { 
		String res = "";
		
		try { 
			int n = service.createEmployee(employee);
			if(n == 1)
				res = "SUCCESS : Employee Record Inserted";
			
		} catch (ClassNotFoundException e) {
			res = " FAILED : DB ERROR";
		} catch (SQLException e) {
			res = "FAILED : DB ERROR";
		} catch (InvalidEmployeeObjectException e) {
			res = "FAILED : " + e;
		}
		
		return res;
	}

	public void findALLEmployee() {
		service.findALLEmployees();
		// TODO Auto-generated method stub
		
	}

}
