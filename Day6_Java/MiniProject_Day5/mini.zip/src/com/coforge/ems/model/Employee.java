package com.coforge.ems.model;

public class Employee {
	private int EmpId;
	private String EmpName;
	private int EmpSal;
	private int EmpDno;
	public Employee(int empId, String empName, int empSal, int empDno) {
		super();
		EmpId = empId;
		EmpName = empName;
		EmpSal = empSal;
		EmpDno = empDno;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public int getEmpSal() {
		return EmpSal;
	}
	public void setEmpSal(int empSal) {
		EmpSal = empSal;
	}
	public int getEmpDno() {
		return EmpDno;
	}
	public void setEmpDno(int empDno) {
		EmpDno = empDno;
	}
	@Override
	public String toString() {
		return "Employee [EmpId=" + EmpId + ", EmpName=" + EmpName + ", EmpSal=" + EmpSal + ", EmpDno=" + EmpDno + "]";
	}
	
	
	

}
